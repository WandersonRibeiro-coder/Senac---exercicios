﻿namespace Senac.Calculadora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonZero = new Button();
            buttonPonto = new Button();
            buttonResultado = new Button();
            buttonUm = new Button();
            buttonDois = new Button();
            buttonTres = new Button();
            buttonSoma = new Button();
            buttonQuatro = new Button();
            buttonCinco = new Button();
            buttonSeis = new Button();
            buttonSubtrai = new Button();
            buttonSete = new Button();
            buttonOito = new Button();
            buttonNove = new Button();
            buttonMultiplica = new Button();
            buttonDivide = new Button();
            buttonPercentual = new Button();
            buttonQuadrado = new Button();
            buttonLimpa = new Button();
            textBoxResultado = new TextBox();
            labelHistorico = new Label();
            SuspendLayout();
            // 
            // buttonZero
            // 
            buttonZero.Font = new Font("Segoe UI", 17F);
            buttonZero.Location = new Point(81, 399);
            buttonZero.Name = "buttonZero";
            buttonZero.Size = new Size(50, 50);
            buttonZero.TabIndex = 0;
            buttonZero.Text = "0";
            buttonZero.UseVisualStyleBackColor = true;
            buttonZero.Click += buttonZero_Click;
            // 
            // buttonPonto
            // 
            buttonPonto.Font = new Font("Segoe UI", 17F);
            buttonPonto.Location = new Point(137, 399);
            buttonPonto.Name = "buttonPonto";
            buttonPonto.Size = new Size(50, 50);
            buttonPonto.TabIndex = 1;
            buttonPonto.Text = ",";
            buttonPonto.UseVisualStyleBackColor = true;
            buttonPonto.Click += buttonPonto_Click;
            // 
            // buttonResultado
            // 
            buttonResultado.Font = new Font("Segoe UI", 17F);
            buttonResultado.Location = new Point(193, 399);
            buttonResultado.Name = "buttonResultado";
            buttonResultado.Size = new Size(106, 50);
            buttonResultado.TabIndex = 2;
            buttonResultado.Text = "=";
            buttonResultado.UseVisualStyleBackColor = true;
            buttonResultado.Click += buttonResultado_Click;
            // 
            // buttonUm
            // 
            buttonUm.Font = new Font("Segoe UI", 17F);
            buttonUm.Location = new Point(81, 343);
            buttonUm.Name = "buttonUm";
            buttonUm.Size = new Size(50, 50);
            buttonUm.TabIndex = 3;
            buttonUm.Text = "1";
            buttonUm.UseVisualStyleBackColor = true;
            buttonUm.Click += buttonUm_Click;
            // 
            // buttonDois
            // 
            buttonDois.Font = new Font("Segoe UI", 17F);
            buttonDois.Location = new Point(137, 343);
            buttonDois.Name = "buttonDois";
            buttonDois.Size = new Size(50, 50);
            buttonDois.TabIndex = 4;
            buttonDois.Text = "2";
            buttonDois.UseVisualStyleBackColor = true;
            buttonDois.Click += buttonDois_Click;
            // 
            // buttonTres
            // 
            buttonTres.Font = new Font("Segoe UI", 17F);
            buttonTres.Location = new Point(193, 343);
            buttonTres.Name = "buttonTres";
            buttonTres.Size = new Size(50, 50);
            buttonTres.TabIndex = 5;
            buttonTres.Text = "3";
            buttonTres.UseVisualStyleBackColor = true;
            buttonTres.Click += buttonTres_Click;
            // 
            // buttonSoma
            // 
            buttonSoma.Font = new Font("Segoe UI", 17F);
            buttonSoma.Location = new Point(249, 343);
            buttonSoma.Name = "buttonSoma";
            buttonSoma.Size = new Size(50, 50);
            buttonSoma.TabIndex = 6;
            buttonSoma.Text = "+";
            buttonSoma.UseVisualStyleBackColor = true;
            buttonSoma.Click += buttonSoma_Click;
            // 
            // buttonQuatro
            // 
            buttonQuatro.Font = new Font("Segoe UI", 17F);
            buttonQuatro.Location = new Point(81, 287);
            buttonQuatro.Name = "buttonQuatro";
            buttonQuatro.Size = new Size(50, 50);
            buttonQuatro.TabIndex = 7;
            buttonQuatro.Text = "4";
            buttonQuatro.UseVisualStyleBackColor = true;
            buttonQuatro.Click += buttonQuatro_Click;
            // 
            // buttonCinco
            // 
            buttonCinco.Font = new Font("Segoe UI", 17F);
            buttonCinco.Location = new Point(137, 287);
            buttonCinco.Name = "buttonCinco";
            buttonCinco.Size = new Size(50, 50);
            buttonCinco.TabIndex = 8;
            buttonCinco.Text = "5";
            buttonCinco.UseVisualStyleBackColor = true;
            buttonCinco.Click += buttonCinco_Click;
            // 
            // buttonSeis
            // 
            buttonSeis.Font = new Font("Segoe UI", 17F);
            buttonSeis.Location = new Point(193, 287);
            buttonSeis.Name = "buttonSeis";
            buttonSeis.Size = new Size(50, 50);
            buttonSeis.TabIndex = 9;
            buttonSeis.Text = "6";
            buttonSeis.UseVisualStyleBackColor = true;
            buttonSeis.Click += buttonSeis_Click;
            // 
            // buttonSubtrai
            // 
            buttonSubtrai.Font = new Font("Segoe UI", 17F);
            buttonSubtrai.Location = new Point(249, 287);
            buttonSubtrai.Name = "buttonSubtrai";
            buttonSubtrai.Size = new Size(50, 50);
            buttonSubtrai.TabIndex = 10;
            buttonSubtrai.Text = "-";
            buttonSubtrai.UseVisualStyleBackColor = true;
            buttonSubtrai.Click += buttonSubtrai_Click;
            // 
            // buttonSete
            // 
            buttonSete.Font = new Font("Segoe UI", 17F);
            buttonSete.Location = new Point(81, 231);
            buttonSete.Name = "buttonSete";
            buttonSete.Size = new Size(50, 50);
            buttonSete.TabIndex = 11;
            buttonSete.Text = "7";
            buttonSete.UseVisualStyleBackColor = true;
            buttonSete.Click += buttonSete_Click;
            // 
            // buttonOito
            // 
            buttonOito.Font = new Font("Segoe UI", 17F);
            buttonOito.Location = new Point(137, 231);
            buttonOito.Name = "buttonOito";
            buttonOito.Size = new Size(50, 50);
            buttonOito.TabIndex = 12;
            buttonOito.Text = "8";
            buttonOito.UseVisualStyleBackColor = true;
            buttonOito.Click += buttonOito_Click;
            // 
            // buttonNove
            // 
            buttonNove.Font = new Font("Segoe UI", 17F);
            buttonNove.Location = new Point(193, 231);
            buttonNove.Name = "buttonNove";
            buttonNove.Size = new Size(50, 50);
            buttonNove.TabIndex = 13;
            buttonNove.Text = "9";
            buttonNove.UseVisualStyleBackColor = true;
            buttonNove.Click += buttonNove_Click;
            // 
            // buttonMultiplica
            // 
            buttonMultiplica.Font = new Font("Segoe UI", 17F);
            buttonMultiplica.Location = new Point(249, 231);
            buttonMultiplica.Name = "buttonMultiplica";
            buttonMultiplica.Size = new Size(50, 50);
            buttonMultiplica.TabIndex = 14;
            buttonMultiplica.Text = "x";
            buttonMultiplica.UseVisualStyleBackColor = true;
            buttonMultiplica.Click += buttonMultiplica_Click;
            // 
            // buttonDivide
            // 
            buttonDivide.Font = new Font("Segoe UI", 17F);
            buttonDivide.Location = new Point(249, 175);
            buttonDivide.Name = "buttonDivide";
            buttonDivide.Size = new Size(50, 50);
            buttonDivide.TabIndex = 15;
            buttonDivide.Text = "/";
            buttonDivide.UseVisualStyleBackColor = true;
            buttonDivide.Click += buttonDivide_Click;
            // 
            // buttonPercentual
            // 
            buttonPercentual.Font = new Font("Segoe UI", 17F);
            buttonPercentual.Location = new Point(81, 175);
            buttonPercentual.Name = "buttonPercentual";
            buttonPercentual.Size = new Size(50, 50);
            buttonPercentual.TabIndex = 17;
            buttonPercentual.Text = "%";
            buttonPercentual.UseVisualStyleBackColor = true;
            buttonPercentual.Click += buttonPercentual_Click;
            // 
            // buttonQuadrado
            // 
            buttonQuadrado.Font = new Font("Segoe UI", 17F);
            buttonQuadrado.Location = new Point(137, 175);
            buttonQuadrado.Name = "buttonQuadrado";
            buttonQuadrado.Size = new Size(50, 50);
            buttonQuadrado.TabIndex = 18;
            buttonQuadrado.Text = "x²";
            buttonQuadrado.UseVisualStyleBackColor = true;
            buttonQuadrado.Click += buttonQuadrado_Click;
            // 
            // buttonLimpa
            // 
            buttonLimpa.Font = new Font("Segoe UI", 17F);
            buttonLimpa.Location = new Point(193, 175);
            buttonLimpa.Name = "buttonLimpa";
            buttonLimpa.Size = new Size(50, 50);
            buttonLimpa.TabIndex = 19;
            buttonLimpa.Text = "C";
            buttonLimpa.UseVisualStyleBackColor = true;
            buttonLimpa.Click += buttonLimpa_Click;
            // 
            // textBoxResultado
            // 
            textBoxResultado.Font = new Font("Segoe UI", 12F);
            textBoxResultado.Location = new Point(85, 129);
            textBoxResultado.Name = "textBoxResultado";
            textBoxResultado.Size = new Size(214, 29);
            textBoxResultado.TabIndex = 20;
            textBoxResultado.Text = "0";
            textBoxResultado.TextAlign = HorizontalAlignment.Right;
            // 
            // labelHistorico
            // 
            labelHistorico.AutoSize = true;
            labelHistorico.Font = new Font("Segoe UI", 12F);
            labelHistorico.ForeColor = Color.DarkCyan;
            labelHistorico.Location = new Point(85, 105);
            labelHistorico.Name = "labelHistorico";
            labelHistorico.Size = new Size(19, 21);
            labelHistorico.TabIndex = 21;
            labelHistorico.Text = "0";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(384, 461);
            Controls.Add(labelHistorico);
            Controls.Add(textBoxResultado);
            Controls.Add(buttonLimpa);
            Controls.Add(buttonQuadrado);
            Controls.Add(buttonPercentual);
            Controls.Add(buttonDivide);
            Controls.Add(buttonMultiplica);
            Controls.Add(buttonNove);
            Controls.Add(buttonOito);
            Controls.Add(buttonSete);
            Controls.Add(buttonSubtrai);
            Controls.Add(buttonSeis);
            Controls.Add(buttonCinco);
            Controls.Add(buttonQuatro);
            Controls.Add(buttonSoma);
            Controls.Add(buttonTres);
            Controls.Add(buttonDois);
            Controls.Add(buttonUm);
            Controls.Add(buttonResultado);
            Controls.Add(buttonPonto);
            Controls.Add(buttonZero);
            Name = "Form1";
            Text = "Calculadora";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonZero;
        private Button buttonPonto;
        private Button buttonResultado;
        private Button buttonUm;
        private Button buttonDois;
        private Button buttonTres;
        private Button buttonSoma;
        private Button buttonQuatro;
        private Button buttonCinco;
        private Button buttonSeis;
        private Button buttonSubtrai;
        private Button buttonSete;
        private Button buttonOito;
        private Button buttonNove;
        private Button buttonMultiplica;
        private Button buttonDivide;
        private Button buttonPercentual;
        private Button buttonQuadrado;
        private Button buttonLimpa;
        private TextBox textBoxResultado;
        private Label labelHistorico;
    }
}
